Robert Judka
CS550
Programming Assignment 3

Overview:
    1. Generated output from the manual demo can be found in 'output/'. Both the output from the logs and stdout can be foud there.
    2. Design doc can be found in 'docs/' as 'design.pdf'.
    3. Source code can be found in 'src/'. This includes 'super_peer.cpp' and 'leaf_node.cpp', as well as the Makefile to compile the executables and build the node directories.
    4. Program listing can be found in 'docs/' as 'program_list.txt'.
    5. Verification can be found in 'docs/' as 'test.pdf'.
    6. Performance results can be found in 'docs/' as 'performance.pdf'. Tools/data used for performing the analysis can be found in 'evaluation/'.
    7. Configuration files can be found in 'config/'.
    8. Manual can be found in 'docs/' as 'manual.pdf'.
